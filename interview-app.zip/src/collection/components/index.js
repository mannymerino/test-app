export default from './CollectionListView';
